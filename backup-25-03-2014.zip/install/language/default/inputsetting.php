<?php
	//file content text for input settin page;
	
	$_['text_hostname'] = 'Host name:';
	$_['text_name_hostname'] = 'hostname';
	$_['text_id_hostname'] = 'hostname';
	
	$_['text_username'] = 'User name:';
	$_['text_name_username'] = 'username';
	$_['text_id_username'] = 'username';
	
	$_['text_passwd'] = 'Password';
	$_['text_name_passwd'] = 'passwd';
	$_['text_id_passwd'] = 'passwd';
	
	$_['text_database'] = 'Database name:';
	$_['text_name_database'] = 'database';
	$_['text_id_database'] = 'database';
	
	$_['text_button'] = 'Install!';
	//error 
	$_['error_hostname'] = 'Host name is required!';
	$_['error_username'] = 'User name is required!';
	$_['error_passwd'] = 'Password is required!';
	$_['error_database'] = 'Database name is required!';
	
?>