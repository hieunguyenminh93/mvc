<?php
    class ModelInputSetting extends Model{
        public function writeConfig($path,$data){
            $file = fopen($path,'x');
            
        }
    }
?>