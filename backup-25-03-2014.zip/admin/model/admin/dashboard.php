<?php
	class ModelAdminDashBoard extends Model{
		
	}
?>