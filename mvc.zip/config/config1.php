<?php
define("VERSION","2");
define("SYSTEM_CLASS","/home/hieu/workspace/mvc/system/class");
define("SYSTEM_LIB","/home/hieu/workspace/mvc/system/library");
define("SYSTEM_DB","/home/hieu/workspace/mvc/system/database");
define("ENGINEER", "/home/hieu/workspace/mvc/engineer");
define("TEMPLATE", "/home/hieu/workspace/mvc/themes");
define("DB_HOSTNAME","localhost");
define("DB_USER","root");
define("DB_PASSWD","1234");
define("DB_DRIVER","mysql");
define("DB_DB","mvc");
?>