<?php
	//this file contain text to show in Intall template
	$_['text_result_title'] = 'Installation result!';
	$_['text_result_success'] = 'Installation success!';
	$_['text_result_fail'] = 'Installation fail!';
	//error
	$_['error_hostname'] = 'Host name is required!';
	$_['error_username'] = 'User name is required!';
?>