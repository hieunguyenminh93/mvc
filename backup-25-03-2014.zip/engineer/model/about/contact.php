<?php
	class ModelAboutContact extends Model{
		public function getContactDetail(){
			return a;
		}
	}