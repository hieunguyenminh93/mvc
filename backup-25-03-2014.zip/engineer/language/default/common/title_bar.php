<?php
$_['button_name_home'] = "Home page";
$_['button_name_about'] = "About";
$_['button_name_contact'] = "Contact us";
$_['button_name_customer_logged'] = "My account";
$_['button_name_customer_loggout'] = "Login/Register";
$_['button_name_customer_register'] = "Register";
?>