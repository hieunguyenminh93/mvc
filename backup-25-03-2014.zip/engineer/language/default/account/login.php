<?php
$_['button_login_name'] = "Login";
$_['button_register_name'] = "Register";
$_['username'] = "Username:";
$_['password'] = "Password";
$_['forgot_passwd'] = "I forgot password";
?>